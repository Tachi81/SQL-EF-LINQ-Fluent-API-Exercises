﻿using MovieDbWorkshop.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieDbWorkshop.DAL
{
    public class MovieContext : DbContext
    {
        public MovieContext() : base("name=MovieDbConnectionString")
        {

        }

        public virtual DbSet<Movie> Movies { get; set; }
        public virtual DbSet<Genre> Genres { get; set; }
    }
}
